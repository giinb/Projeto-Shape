# Projeto Shape

Aplicativo web (PWA) para acompanhar os treinos de musculação. Funciona no celular, abre como aplicativo, guarda tudo no próprio aparelho e funciona sem internet depois da primeira abertura.

## O que tem

- **Início:** saudação, data, treino do dia detectado automaticamente, botão INICIAR TREINO, semana, treinos concluídos e último treino.
- **Treino:** carga e repetições por série, marcar série como feita, "última vez" de cada exercício, cronômetro de descanso (60, 90, 120 s ou outro tempo) que continua ao navegar pelo app, anotação por exercício, finalizar com duração e resumo.
- **Ficha:** a divisão de segunda a sexta já cadastrada. Dá para adicionar, excluir, substituir, reordenar e mudar séries e repetições. Sábado e domingo começam vazios e também podem receber treino.
- **Substituição:** alternativas por equipamento (halteres, barra, caneleira, polia, máquina, peso corporal). O histórico do exercício original fica guardado.
- **Minha Evolução:** resumo, evolução das cargas por exercício (maior carga, volume, 1RM estimada), frequência semanal, tempo de treino, peso e medidas (cintura, abdômen, quadril, coxa, braço) com gráficos, e histórico de todos os treinos.
- **Cardio:** modalidade, tempo, distância, intensidade e data, com resumo semanal.
- **Mais:** preferências, backup (baixar, enviar, restaurar, mesclar), ajuda para instalar.

## Como colocar no ar (grátis, com HTTPS)

O app precisa estar em um endereço `https://` para poder ser instalado no celular. O jeito mais simples é o GitHub Pages:

1. No GitHub, clique em **New repository**, nomeie como `projeto-shape` e deixe **Public**.
2. Clique em **uploading an existing file** e arraste **o conteúdo** desta pasta (os arquivos e a pasta `icons`, não a pasta de fora). Confirme em **Commit changes**.
3. Vá em **Settings → Pages**. Em **Branch**, escolha `main` e a pasta `/ (root)`, e salve.
4. Espere 1 a 2 minutos. O endereço será parecido com `https://SEU-USUARIO.github.io/projeto-shape/`.

Alternativas: Netlify (arraste a pasta em app.netlify.com/drop) ou Cloudflare Pages.

## Como instalar no celular

- **Android (Chrome):** abra o endereço, toque em ⋮ e escolha **Instalar app** (ou **Adicionar à tela inicial**).
- **iPhone (Safari):** abra o endereço, toque em **Compartilhar** e escolha **Adicionar à Tela de Início**.

Depois de instalado, abra pelo ícone. Na primeira vez, abra com internet para o app ser guardado no aparelho.

## Seus dados

- Ficam salvos no aparelho (IndexedDB), não em um servidor. Fechar o app não apaga nada.
- **Faça backup de vez em quando** (Mais → Baixar backup). Isso protege contra trocar de celular, limpar os dados do navegador ou desinstalar o app. O arquivo `.json` pode ser guardado no Drive ou enviado para você mesma.
- O treino em andamento é salvo a cada mudança. Se o celular fechar o app no meio do treino, ele volta de onde parou.
- iPhone: o Safari pode apagar dados de sites que ficam muito tempo sem uso. Instalar na Tela de Início e fazer backups evita esse risco.
- Os dados de cada aparelho são separados. Para levar para outro celular, baixe o backup no antigo e use **Restaurar** no novo.

## Limitações conhecidas

- O som e a vibração do descanso só tocam com o app aberto e a tela ligada (os navegadores pausam o app com a tela bloqueada). O app tenta manter a tela acesa durante o treino. Se a tela apagar, o tempo continua correto ao voltar, mas o aviso sonoro não toca.
- A ilustração mostra o músculo trabalhado. A demonstração do movimento abre uma busca no YouTube e precisa de internet.
- Não há sincronização automática entre aparelhos ainda.

## Atualizar o app depois

Depois de mudar qualquer arquivo, abra `sw.js` e troque o número em `const CACHE = 'shape-v1'` (por exemplo `shape-v2`). Assim os celulares recebem a versão nova.

## Sincronização futura

Todo registro tem `id` único, `updatedAt` e marca de exclusão (`deleted`). A função `mergeRecords` em `logic.js` já resolve conflitos (vence a edição mais recente). Para sincronizar, basta criar um serviço que envie e receba esses registros e use `ShapeDB.putMany`.

## Estrutura

`index.html` (página) · `styles.css` (visual) · `app.js` (telas e ações) · `logic.js` (cálculos) · `data.js` (ficha e biblioteca de exercícios) · `db.js` (armazenamento) · `charts.js` (gráficos) · `figure.js` (ilustração) · `sw.js` (offline) · `manifest.webmanifest` e `icons/` (instalação).
